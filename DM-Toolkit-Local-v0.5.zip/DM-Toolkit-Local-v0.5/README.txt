DM TOOLKIT — LOCAL EDITION v0.5

RUNNING:
1. Open the "app" folder.
2. Double-click index.html.
3. It opens in Chrome.

No internet is required.

DATA:
Campaign data is stored locally in the browser. Use Export regularly to make a JSON backup.

INCLUDED:
- Campaign creation and campaign codes
- Dashboard
- Searchable wiki
- Locations, NPCs, monsters, factions, items, quests and lore
- DM notes and player-visible flag
- Character records
- Combat tracker with initiative, HP and AC
- Maps
- Session logs
- Dice roller
- Name, town and quest generators
- Campaign settings
- JSON export/import
