DM TOOLKIT — LOCAL EDITION v0.2

RUNNING:
1. Extract this ZIP.
2. Open the "app" folder.
3. Double-click index.html.
4. It opens in Chrome.

No Node.js, Python, server, or internet is required.

DATA:
Campaign data is stored locally in the browser. Use Export regularly to make a JSON backup.

INCLUDED:
- Campaign creation and campaign codes
- Dashboard
- Searchable wiki
- Locations, NPCs, monsters, factions, items, quests and lore
- DM notes and player-visible flag
- Character records
- Combat tracker with initiative, HP and AC
- Maps
- Session logs
- Dice roller
- Name, town and quest generators
- Campaign settings
- JSON export/import

NEXT:
- DM/player accounts and real permissions
- View as Player
- Multiple characters per player
- Direct image uploads
- Map grid, tokens and fog of war
- Linked entities
- Better combat controls
- More advanced generators
- Optional online version
