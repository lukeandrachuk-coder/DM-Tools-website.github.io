/* =========================================================
   DM TOOLKIT
   LOCAL D&D CAMPAIGN MANAGER
   ========================================================= */

const DB_NAME = "DMToolkit";
const DB_VERSION = 2;

let db = null;

let currentPage = "home";
let currentCampaignId = null;
let currentUserId = null;

let sidebarOpen =
    localStorage.getItem("dm_sidebar_open") !== "false";


/* =========================================================
   DATABASE
   ========================================================= */

function openDB() {

    return new Promise((resolve, reject) => {

        const request =
            indexedDB.open(
                DB_NAME,
                DB_VERSION
            );


        request.onupgradeneeded = event => {

            const database =
                event.target.result;


            if (!database.objectStoreNames.contains("campaigns")) {

                database.createObjectStore(
                    "campaigns",
                    { keyPath: "id" }
                );

            }


            if (!database.objectStoreNames.contains("entries")) {

                database.createObjectStore(
                    "entries",
                    { keyPath: "id" }
                );

            }


            if (!database.objectStoreNames.contains("characters")) {

                database.createObjectStore(
                    "characters",
                    { keyPath: "id" }
                );

            }


            if (!database.objectStoreNames.contains("combats")) {

                database.createObjectStore(
                    "combats",
                    { keyPath: "id" }
                );

            }


            if (!database.objectStoreNames.contains("maps")) {

                database.createObjectStore(
                    "maps",
                    { keyPath: "id" }
                );

            }


            if (!database.objectStoreNames.contains("sessions")) {

                database.createObjectStore(
                    "sessions",
                    { keyPath: "id" }
                );

            }


            /*
               NEW IN VERSION 2:
               Local accounts.
            */

            if (!database.objectStoreNames.contains("accounts")) {

                database.createObjectStore(
                    "accounts",
                    { keyPath: "id" }
                );

            }

        };


        request.onsuccess = event => {

            db = event.target.result;

            resolve(db);

        };


        request.onerror = () => {

            reject(request.error);

        };

    });

}


function all(storeName) {

    return new Promise((resolve,reject) => {

        const transaction =
            db.transaction(
                storeName,
                "readonly"
            );

        const store =
            transaction.objectStore(
                storeName
            );

        const request =
            store.getAll();

        request.onsuccess =
            () => resolve(request.result);

        request.onerror =
            () => reject(request.error);

    });

}


function one(storeName,id) {

    return new Promise((resolve,reject) => {

        const transaction =
            db.transaction(
                storeName,
                "readonly"
            );

        const store =
            transaction.objectStore(
                storeName
            );

        const request =
            store.get(id);

        request.onsuccess =
            () => resolve(request.result);

        request.onerror =
            () => reject(request.error);

    });

}


function put(storeName,object) {

    return new Promise((resolve,reject) => {

        const transaction =
            db.transaction(
                storeName,
                "readwrite"
            );

        const store =
            transaction.objectStore(
                storeName
            );

        const request =
            store.put(object);

        request.onsuccess =
            () => resolve(object);

        request.onerror =
            () => reject(request.error);

    });

}


function del(storeName,id) {

    return new Promise((resolve,reject) => {

        const transaction =
            db.transaction(
                storeName,
                "readwrite"
            );

        const store =
            transaction.objectStore(
                storeName
            );

        const request =
            store.delete(id);

        request.onsuccess =
            () => resolve();

        request.onerror =
            () => reject(request.error);

    });

}


function makeId(prefix="id") {

    return prefix +
        "_" +
        Date.now() +
        "_" +
        Math.random()
            .toString(36)
            .slice(2,9);

}


function esc(value) {

    if (
        value === null ||
        value === undefined
    ) {
        return "";
    }

    return String(value)
        .replaceAll("&","&amp;")
        .replaceAll("<","&lt;")
        .replaceAll(">","&gt;")
        .replaceAll('"',"&quot;")
        .replaceAll("'","&#039;");

}


/* =========================================================
   AUTHENTICATION
   ========================================================= */

function showLogin() {

    document.getElementById(
        "loginPanel"
    ).hidden = false;

    document.getElementById(
        "createAccountPanel"
    ).hidden = true;

}


function showCreateAccount() {

    document.getElementById(
        "loginPanel"
    ).hidden = true;

    document.getElementById(
        "createAccountPanel"
    ).hidden = false;

}


async function createAccount(event) {

    event.preventDefault();


    const username =
        document.getElementById(
            "createUsername"
        ).value.trim();


    const password =
        document.getElementById(
            "createPassword"
        ).value;


    const confirmation =
        document.getElementById(
            "createPasswordConfirm"
        ).value;


    if (password !== confirmation) {

        alert(
            "The passwords do not match."
        );

        return;

    }


    const accounts =
        await all("accounts");


    const duplicate =
        accounts.find(
            account =>
                account.username
                    .toLowerCase() ===
                username.toLowerCase()
        );


    if (duplicate) {

        alert(
            "That username already exists."
        );

        return;

    }


    const account = {

        id:
            makeId("account"),

        username,

        /*
           This is a local browser application,
           not a server-backed authentication system.
           The password is stored locally.
        */

        password,

        createdAt:
            new Date().toISOString()

    };


    await put(
        "accounts",
        account
    );


    /*
       Give older unowned campaign data to
       the first account created.

       This allows your existing v0.2 data
       to survive the upgrade.
    */

    if (accounts.length === 0) {

        await claimLegacyData(
            account.id
        );

    }


    currentUserId =
        account.id;


    localStorage.setItem(
        "dm_current_user",
        account.id
    );


    enterApplication();


    showToast(
        "Account created."
    );

}


async function login(event) {

    event.preventDefault();


    const username =
        document.getElementById(
            "loginUsername"
        ).value.trim();


    const password =
        document.getElementById(
            "loginPassword"
        ).value;


    const accounts =
        await all("accounts");


    const account =
        accounts.find(
            a =>
                a.username.toLowerCase() ===
                username.toLowerCase() &&
                a.password === password
        );


    if (!account) {

        alert(
            "Username or password is incorrect."
        );

        return;

    }


    currentUserId =
        account.id;


    localStorage.setItem(
        "dm_current_user",
        account.id
    );


    enterApplication();


    showToast(
        "Welcome back, " +
        account.username +
        "."
    );

}


async function claimLegacyData(accountId) {

    const stores = [
        "campaigns",
        "entries",
        "characters",
        "combats",
        "maps",
        "sessions"
    ];


    for (const storeName of stores) {

        const records =
            await all(storeName);


        for (const record of records) {

            /*
               Only old records without an owner
               are claimed.
            */

            if (!record.ownerId) {

                record.ownerId =
                    accountId;

                await put(
                    storeName,
                    record
                );

            }

        }

    }

}


async function restoreLogin() {

    const savedUser =
        localStorage.getItem(
            "dm_current_user"
        );


    if (!savedUser) {

        showAuthScreen();

        return;

    }


    const account =
        await one(
            "accounts",
            savedUser
        );


    if (!account) {

        localStorage.removeItem(
            "dm_current_user"
        );

        showAuthScreen();

        return;

    }


    currentUserId =
        account.id;


    enterApplication();

}


function showAuthScreen() {

    document.getElementById(
        "authScreen"
    ).hidden = false;

    document.getElementById(
        "appScreen"
    ).hidden = true;

}


async function enterApplication() {

    document.getElementById(
        "authScreen"
    ).hidden = true;

    document.getElementById(
        "appScreen"
    ).hidden = false;


    const account =
        await one(
            "accounts",
            currentUserId
        );


    document.getElementById(
        "loggedInUser"
    ).textContent =
        account
            ? "👤 " + account.username
            : "";


    applySidebarState();


    const campaigns =
        await getMyCampaigns();


    /*
       Do not automatically open a campaign.
       The new home screen is the campaign launcher.
    */

    currentCampaignId =
        null;


    await updateCampaignTitle();

    render();

}


function logout() {

    currentCampaignId =
        null;

    currentUserId =
        null;


    localStorage.removeItem(
        "dm_current_user"
    );


    showAuthScreen();

    showLogin();

}


/* =========================================================
   ACCOUNT DATA FILTERING
   ========================================================= */

async function getMyCampaigns() {

    if (!currentUserId) {
        return [];
    }


    const campaigns =
        await all("campaigns");


    return campaigns.filter(
        campaign =>
            campaign.ownerId ===
            currentUserId
    );

}


async function getMyRecords(storeName) {

    if (!currentUserId) {
        return [];
    }


    const records =
        await all(storeName);


    return records.filter(
        record =>
            record.ownerId ===
            currentUserId &&
            (
                !currentCampaignId ||
                record.campaignId ===
                currentCampaignId
            )
    );

}


/* =========================================================
   SIDEBAR
   ========================================================= */

function toggleSidebar() {

    sidebarOpen =
        !sidebarOpen;


    localStorage.setItem(
        "dm_sidebar_open",
        sidebarOpen
    );


    applySidebarState();

}


function applySidebarState() {

    const sidebar =
        document.getElementById(
            "sidebar"
        );


    if (!sidebar) {
        return;
    }


    sidebar.classList.toggle(
        "collapsed",
        !sidebarOpen
    );

}


/* =========================================================
   GENERAL UI
   ========================================================= */

function showToast(message) {

    const container =
        document.getElementById(
            "toast-container"
        );


    const toast =
        document.createElement(
            "div"
        );


    toast.className =
        "toast";


    toast.textContent =
        message;


    container.appendChild(
        toast
    );


    setTimeout(
        () => toast.remove(),
        2600
    );

}


function openModal(title,html) {

    const modal =
        document.getElementById(
            "modal"
        );


    document.getElementById(
        "modalTitle"
    ).textContent =
        title;


    document.getElementById(
        "modalBody"
    ).innerHTML =
        html;


    modal.showModal();

}


function closeModal() {

    document.getElementById(
        "modal"
    ).close();

}


function modalFormButtons() {

    return `

        <div class="form-actions">

            <button
                type="button"
                class="secondary-button"
                onclick="closeModal()">

                Cancel

            </button>

            <button
                type="submit"
                class="primary-button">

                Save

            </button>

        </div>

    `;

}


/* =========================================================
   CAMPAIGN TITLE
   ========================================================= */

async function updateCampaignTitle() {

    const title =
        document.getElementById(
            "campaignTitle"
        );


    if (!title) {
        return;
    }


    if (!currentCampaignId) {

        title.textContent =
            "No campaign selected";

        return;

    }


    const campaign =
        await one(
            "campaigns",
            currentCampaignId
        );


    title.textContent =
        campaign?.name ||
        "No campaign selected";

}


/* =========================================================
   CAMPAIGN LAUNCHER / HOME
   ========================================================= */

async function renderHome() {

    const page =
        document.getElementById(
            "page"
        );


    /*
       This is deliberately different from
       the old dashboard.

       The first thing after login is now:
       Campaign Code
       Open Campaign
       New Campaign
    */

    const campaigns =
        await getMyCampaigns();


    page.innerHTML = `

        <div class="campaign-launcher">

            <div class="launcher-emblem">
                🐉
            </div>

            <h1>
                Welcome to the Realm
            </h1>

            <p class="page-subtitle">
                Choose a campaign to continue your adventure.
            </p>


            <div class="launcher-card">

                <h2>
                    Open Campaign
                </h2>

                <p>
                    Enter a campaign code to open a campaign.
                </p>


                <form onsubmit="openCampaignByCode(event)">

                    <div class="campaign-code-row">

                        <input
                            id="campaignCodeInput"
                            placeholder="Campaign code"
                            autocomplete="off"
                            required>

                        <button
                            class="primary-button"
                            type="submit">

                            Open Campaign

                        </button>

                    </div>

                </form>


                <div class="launcher-divider">

                    <span>or</span>

                </div>


                <button
                    class="gold-button launcher-new-button"
                    onclick="showCampaignForm()">

                    ✦ New Campaign

                </button>

            </div>


            ${
                campaigns.length
                    ? `

                        <div class="launcher-existing">

                            <h2>
                                Your Campaigns
                            </h2>

                            ${campaigns
                                .map(
                                    campaign =>
                                        `
                                        <button
                                            class="campaign-list-item"
                                            onclick="
                                                openSpecificCampaign(
                                                    '${campaign.id}'
                                                )
                                            ">

                                            <span>
                                                📜
                                                ${esc(campaign.name)}
                                            </span>

                                            <small>
                                                ${esc(
                                                    campaign.code ||
                                                    "No code"
                                                )}
                                            </small>

                                        </button>
                                        `
                                )
                                .join("")}

                        </div>

                    `
                    : ""
            }

        </div>

    `;

}


async function openCampaignByCode(event) {

    event.preventDefault();


    const code =
        document.getElementById(
            "campaignCodeInput"
        ).value.trim();


    const campaigns =
        await all("campaigns");


    const campaign =
        campaigns.find(
            c =>
                c.code &&
                c.code.toLowerCase() ===
                code.toLowerCase()
        );


    if (!campaign) {

        showToast(
            "No campaign was found with that code."
        );

        return;

    }


    /*
       A campaign code is the local equivalent
       of a join/open code in this offline version.

       We associate the campaign with this account
       so it becomes available to that user.
    */

    campaign.ownerId =
        currentUserId;


    await put(
        "campaigns",
        campaign
    );


    currentCampaignId =
        campaign.id;


    await updateCampaignTitle();


    showToast(
        "Campaign opened."
    );


    render();

}


async function openSpecificCampaign(campaignId) {

    const campaign =
        await one(
            "campaigns",
            campaignId
        );


    if (!campaign) {
        return;
    }


    if (
        campaign.ownerId !==
        currentUserId
    ) {

        showToast(
            "You do not have access to this campaign."
        );

        return;

    }


    currentCampaignId =
        campaignId;


    await updateCampaignTitle();


    render();

}


/* =========================================================
   CAMPAIGN FORM
   ========================================================= */

async function showCampaignForm(campaignId=null) {

    const campaign =
        campaignId
            ? await one(
                "campaigns",
                campaignId
            )
            : null;


    if (
        campaign &&
        campaign.ownerId !==
        currentUserId
    ) {
        return;
    }


    openModal(

        campaign
            ? "Edit Campaign"
            : "New Campaign",

        `

        <form
            onsubmit="
                saveCampaign(
                    event,
                    '${campaignId || ""}'
                )
            ">

            <div class="form-grid">

                <div class="form-field full">

                    <label>
                        Campaign Name
                    </label>

                    <input
                        id="campaignName"
                        required
                        value="${esc(
                            campaign?.name || ""
                        )}"
                        placeholder="The Lost Kingdom">

                </div>


                <div class="form-field">

                    <label>
                        Campaign Code
                    </label>

                    <input
                        id="campaignCode"
                        value="${esc(
                            campaign?.code ||
                            generateCampaignCode()
                        )}"
                        placeholder="ABCD-1234">

                </div>


                <div class="form-field">

                    <label>
                        Dungeon Master
                    </label>

                    <input
                        id="campaignDM"
                        value="${esc(
                            campaign?.dm || ""
                        )}"
                        placeholder="Dungeon Master">

                </div>


                <div class="form-field full">

                    <label>
                        Description
                    </label>

                    <textarea
                        id="campaignDescription"
                        placeholder="Describe the setting, tone, and adventure...">${esc(
                            campaign?.description || ""
                        )}</textarea>

                </div>

            </div>


            ${modalFormButtons()}

        </form>

        `
    );

}


function generateCampaignCode() {

    const letters =
        "ABCDEFGHJKLMNPQRSTUVWXYZ";


    let result = "";


    for (let i=0;i<4;i++) {

        result +=
            letters[
                Math.floor(
                    Math.random() *
                    letters.length
                )
            ];

    }


    result += "-";


    for (let i=0;i<4;i++) {

        result +=
            Math.floor(
                Math.random()*10
            );

    }


    return result;

}


async function saveCampaign(
    event,
    campaignId
) {

    event.preventDefault();


    const existing =
        campaignId
            ? await one(
                "campaigns",
                campaignId
            )
            : null;


    const campaign = {

        id:
            campaignId ||
            makeId("campaign"),

        ownerId:
            currentUserId,

        name:
            document.getElementById(
                "campaignName"
            ).value.trim(),

        code:
            document.getElementById(
                "campaignCode"
            ).value.trim(),

        dm:
            document.getElementById(
                "campaignDM"
            ).value.trim(),

        description:
            document.getElementById(
                "campaignDescription"
            ).value.trim(),

        createdAt:
            existing?.createdAt ||
            new Date().toISOString(),

        updatedAt:
            new Date().toISOString()

    };


    await put(
        "campaigns",
        campaign
    );


    currentCampaignId =
        campaign.id;


    await updateCampaignTitle();


    closeModal();


    showToast(
        campaignId
            ? "Campaign updated."
            : "Campaign created."
    );


    render();

}


/* =========================================================
   PAGE RENDERING
   ========================================================= */

async function render() {

    await updateCampaignTitle();


    document.querySelectorAll(
        ".nav-button"
    ).forEach(button => {

        button.classList.toggle(
            "active",
            button.dataset.page ===
            currentPage
        );

    });


    /*
       All campaign pages except Home
       require a selected campaign.
    */

    if (
        currentPage !== "home" &&
        !currentCampaignId
    ) {

        currentPage = "home";

    }


    switch(currentPage) {

        case "home":
            await renderHome();
            break;

        case "wiki":
            await renderWiki();
            break;

        case "characters":
            await renderCharacters();
            break;

        case "combat":
            await renderCombat();
            break;

        case "maps":
            await renderMaps();
            break;

        case "sessions":
            await renderSessions();
            break;

        case "dice":
            renderDice();
            break;

        case "generators":
            renderGenerators();
            break;

        case "settings":
            await renderSettings();
            break;

        default:
            await renderHome();

    }

}


document.querySelectorAll(
    ".nav-button"
).forEach(button => {

    button.addEventListener(
        "click",
        () => {

            currentPage =
                button.dataset.page;

            render();

        }
    );

});


/* =========================================================
   DASHBOARD
   ========================================================= */

async function renderDashboardData() {

    const [
        entries,
        characters,
        combats,
        maps,
        sessions
    ] = await Promise.all([

        getMyRecords("entries"),
        getMyRecords("characters"),
        getMyRecords("combats"),
        getMyRecords("maps"),
        getMyRecords("sessions")

    ]);


    return {
        entries,
        characters,
        combats,
        maps,
        sessions
    };

}


/* =========================================================
   WIKI
   ========================================================= */

async function renderWiki() {

    const page =
        document.getElementById(
            "page"
        );


    const entries =
        await getMyRecords(
            "entries"
        );


    page.innerHTML = `

        <div class="toolbar">

            <div>

                <h1 class="page-title">
                    Campaign Wiki
                </h1>

                <p class="page-subtitle">
                    Search and manage your world.
                </p>

            </div>


            <button
                class="primary-button"
                onclick="showEntryForm()">

                + Add Wiki Entry

            </button>

        </div>


        <div class="card">

            <div class="form-field search-box">

                <label>
                    Search Wiki
                </label>

                <input
                    id="wikiSearch"
                    placeholder="Search..."
                    oninput="filterWiki()">

            </div>

        </div>


        <div id="wikiResults">

            ${
                entries.length
                    ? entries
                        .map(renderWikiEntry)
                        .join("")
                    : `
                        <div class="empty-state">

                            <strong>
                                No Wiki Entries
                            </strong>

                            Add your first location,
                            NPC, monster, faction,
                            item, quest, or lore entry.

                        </div>
                    `
            }

        </div>

    `;

}


function renderWikiEntry(entry) {

    return `

        <div
            class="card wiki-entry"
            data-search="
                ${esc(
                    (
                        entry.name +
                        " " +
                        entry.type +
                        " " +
                        entry.description
                    ).toLowerCase()
                )}
            ">

            ${
                entry.image
                    ? `
                        <img
                            class="entry-image"
                            src="${esc(entry.image)}">
                    `
                    : `
                        <div class="entry-image placeholder">
                            📖
                        </div>
                    `
            }


            <div style="flex:1">

                <div class="card-header">

                    <div>

                        <span class="tag">
                            ${esc(
                                entry.type ||
                                "Lore"
                            )}
                        </span>

                        <h2>
                            ${esc(entry.name)}
                        </h2>

                    </div>


                    <div>

                        <button
                            class="small-button"
                            onclick="
                                showEntryForm(
                                    '${entry.id}'
                                )
                            ">

                            Edit

                        </button>


                        <button
                            class="small-button"
                            onclick="
                                deleteEntry(
                                    '${entry.id}'
                                )
                            ">

                            Delete

                        </button>

                    </div>

                </div>


                <p>
                    ${esc(
                        entry.description ||
                        "No description."
                    )}
                </p>

            </div>

        </div>

    `;

}


function filterWiki() {

    const query =
        document.getElementById(
            "wikiSearch"
        ).value.toLowerCase();


    document.querySelectorAll(
        "[data-search]"
    ).forEach(element => {

        element.style.display =
            element.dataset.search
                .includes(query)
                ? ""
                : "none";

    });

}


async function showEntryForm(entryId=null) {

    const entry =
        entryId
            ? await one(
                "entries",
                entryId
            )
            : null;


    const types = [

        "Location",
        "NPC",
        "Monster",
        "Faction",
        "Item",
        "Quest",
        "Lore"

    ];


    openModal(

        entry
            ? "Edit Wiki Entry"
            : "Add Wiki Entry",

        `

        <form
            onsubmit="
                saveEntry(
                    event,
                    '${entryId || ""}'
                )
            ">

            <div class="form-grid">

                <div class="form-field">

                    <label>
                        Name
                    </label>

                    <input
                        id="entryName"
                        required
                        value="${esc(
                            entry?.name || ""
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Type
                    </label>

                    <select id="entryType">

                        ${types
                            .map(
                                type =>
                                    `
                                    <option
                                        ${
                                            entry?.type ===
                                            type
                                            ? "selected"
                                            : ""
                                        }>
                                        ${type}
                                    </option>
                                    `
                            )
                            .join("")}

                    </select>

                </div>


                <div class="form-field full">

                    <label>
                        Description
                    </label>

                    <textarea
                        id="entryDescription">${esc(
                            entry?.description ||
                            ""
                        )}</textarea>

                </div>


                <div class="form-field full">

                    <label>
                        DM Notes
                    </label>

                    <textarea
                        id="entryNotes">${esc(
                            entry?.notes ||
                            ""
                        )}</textarea>

                </div>


                <div class="form-field full">

                    <label>
                        Image URL
                    </label>

                    <input
                        id="entryImage"
                        value="${esc(
                            entry?.image ||
                            ""
                        )}">

                </div>


                <div class="checkbox-row">

                    <input
                        id="entryPlayerVisible"
                        type="checkbox"
                        ${
                            entry?.playerVisible
                                ? "checked"
                                : ""
                        }>

                    <label>
                        Visible to players
                    </label>

                </div>

            </div>


            ${modalFormButtons()}

        </form>

        `
    );

}


async function saveEntry(
    event,
    entryId
) {

    event.preventDefault();


    const existing =
        entryId
            ? await one(
                "entries",
                entryId
            )
            : null;


    const entry = {

        id:
            entryId ||
            makeId("entry"),

        ownerId:
            currentUserId,

        campaignId:
            currentCampaignId,

        name:
            document.getElementById(
                "entryName"
            ).value.trim(),

        type:
            document.getElementById(
                "entryType"
            ).value,

        description:
            document.getElementById(
                "entryDescription"
            ).value.trim(),

        notes:
            document.getElementById(
                "entryNotes"
            ).value.trim(),

        image:
            document.getElementById(
                "entryImage"
            ).value.trim(),

        playerVisible:
            document.getElementById(
                "entryPlayerVisible"
            ).checked,

        createdAt:
            existing?.createdAt ||
            new Date().toISOString(),

        updatedAt:
            new Date().toISOString()

    };


    await put(
        "entries",
        entry
    );


    closeModal();

    showToast(
        entryId
            ? "Wiki entry updated."
            : "Wiki entry created."
    );


    render();

}


async function deleteEntry(id) {

    if (
        !confirm(
            "Delete this wiki entry?"
        )
    ) {
        return;
    }


    await del(
        "entries",
        id
    );


    showToast(
        "Wiki entry deleted."
    );


    render();

}


/* =========================================================
   CHARACTERS
   ========================================================= */

async function renderCharacters() {

    const page =
        document.getElementById(
            "page"
        );


    const characters =
        await getMyRecords(
            "characters"
        );


    page.innerHTML = `

        <div class="toolbar">

            <div>

                <h1 class="page-title">
                    Characters
                </h1>

                <p class="page-subtitle">
                    Player characters and campaign information.
                </p>

            </div>


            <button
                class="primary-button"
                onclick="showCharacterForm()">

                + Add Character

            </button>

        </div>


        ${
            characters.length
                ? `
                    <div class="character-grid">

                        ${characters
                            .map(
                                character =>
                                    `
                                    <div class="character-card">

                                        ${
                                            character.image
                                                ? `
                                                    <img
                                                        class="character-card-image"
                                                        src="${esc(
                                                            character.image
                                                        )}">
                                                `
                                                : `
                                                    <div
                                                        class="character-card-image"
                                                        style="
                                                            display:flex;
                                                            align-items:center;
                                                            justify-content:center;
                                                            font-size:55px;
                                                        ">
                                                        ♙
                                                    </div>
                                                `
                                        }


                                        <div class="character-card-body">

                                            <h3>
                                                ${esc(
                                                    character.name
                                                )}
                                            </h3>

                                            <p>
                                                <strong>
                                                    Player:
                                                </strong>
                                                ${esc(
                                                    character.player ||
                                                    "Unassigned"
                                                )}
                                            </p>

                                            <p>
                                                ${esc(
                                                    character.race ||
                                                    ""
                                                )}
                                                ${
                                                    character.className
                                                        ? " • " +
                                                          esc(
                                                              character.className
                                                          )
                                                        : ""
                                                }
                                            </p>


                                            <button
                                                class="small-button"
                                                onclick="
                                                    showCharacterForm(
                                                        '${character.id}'
                                                    )
                                                ">

                                                Edit

                                            </button>


                                            <button
                                                class="small-button"
                                                onclick="
                                                    deleteCharacter(
                                                        '${character.id}'
                                                    )
                                                ">

                                                Delete

                                            </button>

                                        </div>

                                    </div>
                                    `
                            )
                            .join("")}

                    </div>
                `
                : `
                    <div class="empty-state">

                        <strong>
                            No Characters
                        </strong>

                        Add a player character.

                    </div>
                `
        }

    `;

}


async function showCharacterForm(
    characterId=null
) {

    const character =
        characterId
            ? await one(
                "characters",
                characterId
            )
            : null;


    openModal(

        character
            ? "Edit Character"
            : "Add Character",

        `

        <form
            onsubmit="
                saveCharacter(
                    event,
                    '${characterId || ""}'
                )
            ">

            <div class="form-grid">

                <div class="form-field">

                    <label>
                        Character Name
                    </label>

                    <input
                        id="characterName"
                        required
                        value="${esc(
                            character?.name ||
                            ""
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Player
                    </label>

                    <input
                        id="characterPlayer"
                        value="${esc(
                            character?.player ||
                            ""
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Race / Species
                    </label>

                    <input
                        id="characterRace"
                        value="${esc(
                            character?.race ||
                            ""
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Class
                    </label>

                    <input
                        id="characterClass"
                        value="${esc(
                            character?.className ||
                            ""
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Level
                    </label>

                    <input
                        id="characterLevel"
                        type="number"
                        min="1"
                        value="${esc(
                            character?.level ||
                            1
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Image URL
                    </label>

                    <input
                        id="characterImage"
                        value="${esc(
                            character?.image ||
                            ""
                        )}">

                </div>


                <div class="form-field full">

                    <label>
                        Description
                    </label>

                    <textarea
                        id="characterDescription">${esc(
                            character?.description ||
                            ""
                        )}</textarea>

                </div>


                <div class="form-field full">

                    <label>
                        DM Notes
                    </label>

                    <textarea
                        id="characterNotes">${esc(
                            character?.notes ||
                            ""
                        )}</textarea>

                </div>

            </div>


            ${modalFormButtons()}

        </form>

        `
    );

}


async function saveCharacter(
    event,
    characterId
) {

    event.preventDefault();


    const existing =
        characterId
            ? await one(
                "characters",
                characterId
            )
            : null;


    const character = {

        id:
            characterId ||
            makeId("character"),

        ownerId:
            currentUserId,

        campaignId:
            currentCampaignId,

        name:
            document.getElementById(
                "characterName"
            ).value.trim(),

        player:
            document.getElementById(
                "characterPlayer"
            ).value.trim(),

        race:
            document.getElementById(
                "characterRace"
            ).value.trim(),

        className:
            document.getElementById(
                "characterClass"
            ).value.trim(),

        level:
            Number(
                document.getElementById(
                    "characterLevel"
                ).value
            ) || 1,

        image:
            document.getElementById(
                "characterImage"
            ).value.trim(),

        description:
            document.getElementById(
                "characterDescription"
            ).value.trim(),

        notes:
            document.getElementById(
                "characterNotes"
            ).value.trim(),

        createdAt:
            existing?.createdAt ||
            new Date().toISOString(),

        updatedAt:
            new Date().toISOString()

    };


    await put(
        "characters",
        character
    );


    closeModal();

    showToast(
        characterId
            ? "Character updated."
            : "Character created."
    );


    render();

}


async function deleteCharacter(id) {

    if (
        !confirm(
            "Delete this character?"
        )
    ) {
        return;
    }


    await del(
        "characters",
        id
    );


    showToast(
        "Character deleted."
    );


    render();

}


/* =========================================================
   COMBAT
   ========================================================= */

function normalizeCombat(combat) {

    return {

        ...combat,

        status:
            combat.status ||
            "draft",

        round:
            Number(combat.round) ||
            1,

        turnIndex:
            Number(combat.turnIndex) ||
            0,

        p:
            Array.isArray(combat.p)
                ? combat.p.map(
                    participant => ({

                        id:
                            participant.id ||
                            makeId("participant"),

                        n:
                            participant.n ||
                            participant.name ||
                            "Unnamed",

                        i:
                            Number(
                                participant.i
                            ) || 0,

                        h:
                            Number(
                                participant.h
                            ) || 0,

                        m:
                            Number(
                                participant.m
                            ) ||
                            Number(
                                participant.h
                            ) ||
                            1,

                        a:
                            Number(
                                participant.a
                            ) || 10,

                        tempHp:
                            Number(
                                participant.tempHp
                            ) || 0,

                        conditions:
                            participant.conditions ||
                            "",

                        notes:
                            participant.notes ||
                            "",

                        hidden:
                            Boolean(
                                participant.hidden
                            ),

                        isPlayer:
                            Boolean(
                                participant.isPlayer
                            )

                    })
                )
                : []

    };

}


async function renderCombat() {

    const page =
        document.getElementById(
            "page"
        );


    let combats =
        await getMyRecords(
            "combats"
        );


    combats =
        combats.map(
            normalizeCombat
        );


    for (
        const combat of combats
    ) {

        await put(
            "combats",
            combat
        );

    }


    const active =
        combats.find(
            c =>
                c.status ===
                "active"
        );


    const drafts =
        combats.filter(
            c =>
                c.status ===
                "draft"
        );


    const ended =
        combats.filter(
            c =>
                c.status ===
                "ended"
        );


    page.innerHTML = `

        <div class="toolbar">

            <div>

                <h1 class="page-title">
                    Combat
                </h1>

                <p class="page-subtitle">
                    Run encounters and track the battlefield.
                </p>

            </div>


            <div class="toolbar-right">

                <button
                    class="secondary-button"
                    onclick="showCombatForm()">

                    + Create Encounter

                </button>


                <button
                    class="primary-button"
                    onclick="startCombatModal()">

                    ⚔ Start Combat

                </button>

            </div>

        </div>


        ${
            active
                ? renderActiveCombat(active)
                : `
                    <div class="card empty-state">

                        <strong>
                            No Active Combat
                        </strong>

                        Create an encounter,
                        then start it when ready.

                    </div>
                `
        }


        ${
            drafts.length
                ? `

                    <div class="card">

                        <h2>
                            Prepared Encounters
                        </h2>

                        ${drafts
                            .map(
                                renderCombatSummary
                            )
                            .join("")}

                    </div>

                `
                : ""
        }


        ${
            ended.length
                ? `

                    <div class="card">

                        <h2>
                            Combat History
                        </h2>

                        ${ended
                            .map(
                                renderCombatSummary
                            )
                            .join("")}

                    </div>

                `
                : ""
        }

    `;

}


function renderCombatSummary(
    combat
) {

    return `

        <div class="card combat-card">

            <div class="card-header">

                <div>

                    <span
                        class="
                            combat-status
                            ${esc(combat.status)}
                        ">

                        ${esc(combat.status)}

                    </span>


                    <h3 style="margin-top:8px">

                        ${esc(combat.name)}

                    </h3>

                    <div>
                        ${combat.p.length}
                        participant(s)
                    </div>

                </div>


                <div class="toolbar-right">

                    ${
                        combat.status ===
                        "draft"
                            ? `

                                <button
                                    class="small-button"
                                    onclick="
                                        showCombatForm(
                                            '${combat.id}'
                                        )
                                    ">

                                    Edit

                                </button>


                                <button
                                    class="small-button"
                                    onclick="
                                        startSpecificCombat(
                                            '${combat.id}'
                                        )
                                    ">

                                    Start

                                </button>

                            `
                            : `
                                <button
                                    class="small-button"
                                    onclick="
                                        showCombatForm(
                                            '${combat.id}'
                                        )
                                    ">

                                    View / Edit

                                </button>
                            `
                    }


                    <button
                        class="small-button"
                        onclick="
                            deleteCombat(
                                '${combat.id}'
                            )
                        ">

                        Delete

                    </button>

                </div>

            </div>

        </div>

    `;

}


function renderActiveCombat(
    combat
) {

    const participants =
        [...combat.p].sort(
            (a,b) =>
                Number(b.i) -
                Number(a.i)
        );


    return `

        <div class="card combat-card active-combat">

            <div class="card-header">

                <div>

                    <span class="combat-status active">
                        Active
                    </span>

                    <h2 style="margin-top:8px">
                        ${esc(combat.name)}
                    </h2>

                    <strong>
                        Round ${combat.round}
                    </strong>

                </div>


                <div class="toolbar-right">

                    <button
                        class="secondary-button"
                        onclick="
                            showCombatForm(
                                '${combat.id}'
                            )
                        ">

                        Edit Combat

                    </button>


                    <button
                        class="secondary-button"
                        onclick="
                            previousTurn(
                                '${combat.id}'
                            )
                        ">

                        ← Previous

                    </button>


                    <button
                        class="primary-button"
                        onclick="
                            nextTurn(
                                '${combat.id}'
                            )
                        ">

                        Next Turn →

                    </button>


                    <button
                        class="danger-button"
                        onclick="
                            endCombat(
                                '${combat.id}'
                            )
                        ">

                        End Combat

                    </button>

                </div>

            </div>


            <div class="toolbar">

                <button
                    class="secondary-button"
                    onclick="
                        nextRound(
                            '${combat.id}'
                        )
                    ">

                    Next Round

                </button>


                <button
                    class="primary-button"
                    onclick="
                        showParticipantForm(
                            '${combat.id}'
                        )
                    ">

                    + Add Participant

                </button>

            </div>


            <div class="table-wrap">

                <table>

                    <thead>

                        <tr>

                            <th>Turn</th>
                            <th>Initiative</th>
                            <th>Combatant</th>
                            <th>HP</th>
                            <th>Health</th>
                            <th>Damage</th>
                            <th>AC</th>
                            <th>Conditions</th>
                            <th>Actions</th>

                        </tr>

                    </thead>


                    <tbody>

                        ${
                            participants
                                .map(
                                    (p,index) =>
                                        renderCombatParticipant(
                                            combat,
                                            p,
                                            index
                                        )
                                )
                                .join("")
                        }

                    </tbody>

                </table>

            </div>

        </div>

    `;

}


function renderCombatParticipant(
    combat,
    participant,
    sortedIndex
) {

    const isTurn =
        sortedIndex ===
        combat.turnIndex;


    const max =
        Math.max(
            Number(participant.m) ||
            1,
            1
        );


    const hp =
        Math.max(
            Number(participant.h) ||
            0,
            0
        );


    const percent =
        Math.max(
            0,
            Math.min(
                100,
                hp / max * 100
            )
        );


    let healthClass = "";


    if (percent <= 25) {

        healthClass =
            "critical";

    } else if (percent <= 50) {

        healthClass =
            "low";

    }


    return `

        <tr
            class="
                ${isTurn
                    ? "turn-indicator"
                    : ""}
            ">

            <td>
                ${
                    isTurn
                        ? "⚔"
                        : ""
                }
            </td>


            <td>
                ${esc(participant.i)}
            </td>


            <td>

                <strong>
                    ${esc(participant.n)}
                </strong>

            </td>


            <td>

                ${hp} / ${max}

                ${
                    participant.tempHp
                        ? `
                            <br>
                            <small>
                                +${participant.tempHp}
                                temp
                            </small>
                        `
                        : ""
                }

            </td>


            <td>

                <div class="hp-bar">

                    <div
                        class="
                            hp-fill
                            ${healthClass}
                        "
                        style="
                            width:${percent}%
                        ">
                    </div>

                </div>

            </td>


            <td>

                <div class="damage-control">

                    <input
                        type="number"
                        min="0"
                        placeholder="Damage"
                        id="
                            damage_${combat.id}_${participant.id}
                        "
                        onkeydown="
                            if(event.key === 'Enter'){
                                applyDamage(
                                    '${combat.id}',
                                    '${participant.id}',
                                    this
                                );
                            }
                        ">


                    <button
                        class="small-button"
                        onclick="
                            applyDamage(
                                '${combat.id}',
                                '${participant.id}',
                                document.getElementById(
                                    'damage_${combat.id}_${participant.id}'
                                )
                            )
                        ">

                        Apply

                    </button>

                </div>


                <button
                    class="small-button"
                    style="margin-top:4px"
                    onclick="
                        showHealForm(
                            '${combat.id}',
                            '${participant.id}'
                        )
                    ">

                    Heal

                </button>

            </td>


            <td>
                ${esc(participant.a)}
            </td>


            <td>
                ${
                    participant.conditions
                        ? esc(
                            participant.conditions
                        )
                        : "—"
                }
            </td>


            <td>

                <button
                    class="small-button"
                    onclick="
                        showParticipantForm(
                            '${combat.id}',
                            '${participant.id}'
                        )
                    ">

                    Edit

                </button>


                <button
                    class="small-button"
                    onclick="
                        removeParticipant(
                            '${combat.id}',
                            '${participant.id}'
                        )
                    ">

                    ×

                </button>

            </td>

        </tr>

    `;

}


/* =========================================================
   COMBAT FORMS
   ========================================================= */

async function showCombatForm(
    combatId=null
) {

    const combat =
        combatId
            ? normalizeCombat(
                await one(
                    "combats",
                    combatId
                )
            )
            : null;


    openModal(

        combat
            ? "Edit Encounter"
            : "Create Encounter",

        `

        <form
            onsubmit="
                saveCombat(
                    event,
                    '${combatId || ""}'
                )
            ">

            <div class="form-grid">

                <div class="form-field full">

                    <label>
                        Encounter Name
                    </label>

                    <input
                        id="combatName"
                        required
                        value="${esc(
                            combat?.name ||
                            ""
                        )}"
                        placeholder="Goblin Ambush">

                </div>


                <div class="form-field full">

                    <label>
                        Encounter Notes
                    </label>

                    <textarea
                        id="combatNotes">${esc(
                            combat?.notes ||
                            ""
                        )}</textarea>

                </div>

            </div>


            <div class="card">

                <h3>
                    Participants
                </h3>

                ${
                    combat?.p?.length
                        ? combat.p
                            .map(
                                p =>
                                    `
                                    <div class="toolbar">

                                        <strong>
                                            ${esc(p.n)}
                                        </strong>

                                        <span>
                                            Initiative:
                                            ${esc(p.i)}
                                            |
                                            HP:
                                            ${esc(p.h)}
                                            /
                                            ${esc(p.m)}
                                        </span>

                                    </div>
                                    `
                            )
                            .join("")
                        : `
                            <p>
                                Add participants after creating
                                the encounter.
                            </p>
                        `
                }

            </div>


            ${modalFormButtons()}

        </form>

        `
    );

}


async function saveCombat(
    event,
    combatId
) {

    event.preventDefault();


    const existing =
        combatId
            ? normalizeCombat(
                await one(
                    "combats",
                    combatId
                )
            )
            : null;


    const combat = {

        id:
            combatId ||
            makeId("combat"),

        ownerId:
            currentUserId,

        campaignId:
            currentCampaignId,

        name:
            document.getElementById(
                "combatName"
            ).value.trim(),

        notes:
            document.getElementById(
                "combatNotes"
            ).value.trim(),

        status:
            existing?.status ||
            "draft",

        round:
            existing?.round ||
            1,

        turnIndex:
            existing?.turnIndex ||
            0,

        p:
            existing?.p ||
            [],

        createdAt:
            existing?.createdAt ||
            new Date().toISOString(),

        updatedAt:
            new Date().toISOString(),

        endedAt:
            existing?.endedAt ||
            null

    };


    await put(
        "combats",
        combat
    );


    closeModal();


    showToast(
        combatId
            ? "Encounter updated."
            : "Encounter created."
    );


    render();

}


async function startCombatModal() {

    const combats =
        (await getMyRecords(
            "combats"
        ))
        .filter(
            c =>
                !c.status ||
                c.status ===
                "draft"
        );


    if (!combats.length) {

        showToast(
            "Create an encounter first."
        );

        return;

    }


    openModal(

        "Start Combat",

        `

        <div class="form-field">

            <label>
                Encounter
            </label>

            <select id="startCombatSelect">

                ${combats
                    .map(
                        c =>
                            `
                            <option
                                value="${esc(c.id)}">

                                ${esc(c.name)}

                            </option>
                            `
                    )
                    .join("")}

            </select>

        </div>


        <div class="form-actions">

            <button
                class="secondary-button"
                onclick="closeModal()">

                Cancel

            </button>


            <button
                class="primary-button"
                onclick="confirmStartCombat()">

                ⚔ Start Combat

            </button>

        </div>

        `
    );

}


async function confirmStartCombat() {

    const combatId =
        document.getElementById(
            "startCombatSelect"
        ).value;


    await startSpecificCombat(
        combatId
    );

}


async function startSpecificCombat(
    combatId
) {

    const combats =
        await getMyRecords(
            "combats"
        );


    const active =
        combats.find(
            c =>
                c.status ===
                "active"
        );


    if (active) {

        showToast(
            "End the current combat first."
        );

        closeModal();

        return;

    }


    const combat =
        normalizeCombat(
            await one(
                "combats",
                combatId
            )
        );


    if (!combat) {
        return;
    }


    combat.status =
        "active";


    combat.round =
        1;


    combat.turnIndex =
        0;


    combat.p.sort(
        (a,b) =>
            Number(b.i) -
            Number(a.i)
    );


    await put(
        "combats",
        combat
    );


    closeModal();


    showToast(
        "Combat started!"
    );


    render();

}


async function endCombat(
    combatId
) {

    const combat =
        normalizeCombat(
            await one(
                "combats",
                combatId
            )
        );


    if (!combat) {
        return;
    }


    if (
        !confirm(
            "End this combat and save it to history?"
        )
    ) {
        return;
    }


    combat.status =
        "ended";


    combat.endedAt =
        new Date().toISOString();


    await put(
        "combats",
        combat
    );


    showToast(
        "Combat ended."
    );


    render();

}


async function nextTurn(
    combatId
) {

    const combat =
        normalizeCombat(
            await one(
                "combats",
                combatId
            )
        );


    if (
        !combat ||
        !combat.p.length
    ) {
        return;
    }


    combat.turnIndex++;


    if (
        combat.turnIndex >=
        combat.p.length
    ) {

        combat.turnIndex =
            0;

        combat.round++;

    }


    await put(
        "combats",
        combat
    );


    render();

}


async function previousTurn(
    combatId
) {

    const combat =
        normalizeCombat(
            await one(
                "combats",
                combatId
            )
        );


    if (
        !combat ||
        !combat.p.length
    ) {
        return;
    }


    combat.turnIndex--;


    if (
        combat.turnIndex < 0
    ) {

        combat.turnIndex =
            combat.p.length - 1;

        combat.round =
            Math.max(
                1,
                combat.round - 1
            );

    }


    await put(
        "combats",
        combat
    );


    render();

}


async function nextRound(
    combatId
) {

    const combat =
        normalizeCombat(
            await one(
                "combats",
                combatId
            )
        );


    if (!combat) {
        return;
    }


    combat.round++;

    combat.turnIndex =
        0;


    await put(
        "combats",
        combat
    );


    render();

}


/* =========================================================
   DAMAGE
   ========================================================= */

async function applyDamage(
    combatId,
    participantId,
    input
) {

    const damage =
        Math.max(
            0,
            Number(input.value) ||
            0
        );


    if (!damage) {
        return;
    }


    const combat =
        normalizeCombat(
            await one(
                "combats",
                combatId
            )
        );


    const participant =
        combat?.p.find(
            p =>
                p.id ===
                participantId
        );


    if (!participant) {
        return;
    }


    let remaining =
        damage;


    /*
       Temporary HP absorbs damage first.
    */

    if (
        participant.tempHp >
        0
    ) {

        const absorbed =
            Math.min(
                participant.tempHp,
                remaining
            );


        participant.tempHp -=
            absorbed;


        remaining -=
            absorbed;

    }


    participant.h =
        Math.max(
            0,
            participant.h -
            remaining
        );


    await put(
        "combats",
        combat
    );


    input.value =
        "";


    showToast(
        participant.n +
        " took " +
        damage +
        " damage."
    );


    render();

}


/* =========================================================
   HEAL FORM
   ========================================================= */

async function showHealForm(
    combatId,
    participantId
) {

    openModal(

        "Restore Hit Points",

        `

        <form
            onsubmit="
                applyHeal(
                    event,
                    '${combatId}',
                    '${participantId}'
                )
            ">

            <div class="form-field">

                <label>
                    Healing Amount
                </label>

                <input
                    id="healAmount"
                    type="number"
                    min="1"
                    required
                    autofocus>

            </div>


            ${modalFormButtons()}

        </form>

        `
    );

}


async function applyHeal(
    event,
    combatId,
    participantId
) {

    event.preventDefault();


    const amount =
        Math.max(
            0,
            Number(
                document.getElementById(
                    "healAmount"
                ).value
            ) || 0
        );


    const combat =
        normalizeCombat(
            await one(
                "combats",
                combatId
            )
        );


    const participant =
        combat?.p.find(
            p =>
                p.id ===
                participantId
        );


    if (
        !participant ||
        !amount
    ) {
        return;
    }


    participant.h =
        Math.min(
            participant.m,
            participant.h +
            amount
        );


    await put(
        "combats",
        combat
    );


    closeModal();


    showToast(
        participant.n +
        " recovered " +
        amount +
        " HP."
    );


    render();

}


/* =========================================================
   PARTICIPANTS
   ========================================================= */

async function showParticipantForm(
    combatId,
    participantId=null
) {

    const combat =
        normalizeCombat(
            await one(
                "combats",
                combatId
            )
        );


    const participant =
        participantId
            ? combat.p.find(
                p =>
                    p.id ===
                    participantId
            )
            : null;


    openModal(

        participant
            ? "Edit Combatant"
            : "Add Combatant",

        `

        <form
            onsubmit="
                saveParticipant(
                    event,
                    '${combatId}',
                    '${participantId || ""}'
                )
            ">

            <div class="form-grid">

                <div class="form-field full">

                    <label>
                        Name
                    </label>

                    <input
                        id="participantName"
                        required
                        value="${esc(
                            participant?.n ||
                            ""
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Initiative
                    </label>

                    <input
                        id="participantInitiative"
                        type="number"
                        value="${esc(
                            participant?.i ||
                            0
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Armor Class
                    </label>

                    <input
                        id="participantAC"
                        type="number"
                        value="${esc(
                            participant?.a ||
                            10
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Current HP
                    </label>

                    <input
                        id="participantHP"
                        type="number"
                        min="0"
                        value="${esc(
                            participant?.h ||
                            10
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Maximum HP
                    </label>

                    <input
                        id="participantMaxHP"
                        type="number"
                        min="1"
                        value="${esc(
                            participant?.m ||
                            10
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Temporary HP
                    </label>

                    <input
                        id="participantTempHP"
                        type="number"
                        min="0"
                        value="${esc(
                            participant?.tempHp ||
                            0
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Conditions
                    </label>

                    <input
                        id="participantConditions"
                        value="${esc(
                            participant?.conditions ||
                            ""
                        )}"
                        placeholder="Poisoned, Prone...">

                </div>


                <div class="form-field full">

                    <label>
                        Notes
                    </label>

                    <textarea
                        id="participantNotes">${esc(
                            participant?.notes ||
                            ""
                        )}</textarea>

                </div>


                <div class="checkbox-row">

                    <input
                        id="participantPlayer"
                        type="checkbox"
                        ${
                            participant?.isPlayer
                                ? "checked"
                                : ""
                        }>

                    <label>
                        Player Character
                    </label>

                </div>


                <div class="checkbox-row">

                    <input
                        id="participantHidden"
                        type="checkbox"
                        ${
                            participant?.hidden
                                ? "checked"
                                : ""
                        }>

                    <label>
                        Hidden from Players
                    </label>

                </div>

            </div>


            ${modalFormButtons()}

        </form>

        `
    );

}


async function saveParticipant(
    event,
    combatId,
    participantId
) {

    event.preventDefault();


    const combat =
        normalizeCombat(
            await one(
                "combats",
                combatId
            )
        );


    const maxHP =
        Math.max(
            1,
            Number(
                document.getElementById(
                    "participantMaxHP"
                ).value
            ) || 1
        );


    const participant = {

        id:
            participantId ||
            makeId("participant"),

        n:
            document.getElementById(
                "participantName"
            ).value.trim(),

        i:
            Number(
                document.getElementById(
                    "participantInitiative"
                ).value
            ) || 0,

        h:
            Math.min(
                maxHP,
                Math.max(
                    0,
                    Number(
                        document.getElementById(
                            "participantHP"
                        ).value
                    ) || 0
                )
            ),

        m:
            maxHP,

        a:
            Number(
                document.getElementById(
                    "participantAC"
                ).value
            ) || 10,

        tempHp:
            Math.max(
                0,
                Number(
                    document.getElementById(
                        "participantTempHP"
                    ).value
                ) || 0
            ),

        conditions:
            document.getElementById(
                "participantConditions"
            ).value.trim(),

        notes:
            document.getElementById(
                "participantNotes"
            ).value.trim(),

        isPlayer:
            document.getElementById(
                "participantPlayer"
            ).checked,

        hidden:
            document.getElementById(
                "participantHidden"
            ).checked

    };


    if (participantId) {

        const index =
            combat.p.findIndex(
                p =>
                    p.id ===
                    participantId
            );


        combat.p[index] =
            participant;

    } else {

        combat.p.push(
            participant
        );

    }


    combat.p.sort(
        (a,b) =>
            Number(b.i) -
            Number(a.i)
    );


    await put(
        "combats",
        combat
    );


    closeModal();


    showToast(
        participantId
            ? "Combatant updated."
            : "Combatant added."
    );


    render();

}


async function removeParticipant(
    combatId,
    participantId
) {

    const combat =
        normalizeCombat(
            await one(
                "combats",
                combatId
            )
        );


    const participant =
        combat?.p.find(
            p =>
                p.id ===
                participantId
        );


    if (!participant) {
        return;
    }


    if (
        !confirm(
            "Remove " +
            participant.n +
            "?"
        )
    ) {
        return;
    }


    combat.p =
        combat.p.filter(
            p =>
                p.id !==
                participantId
        );


    await put(
        "combats",
        combat
    );


    render();

}


async function deleteCombat(
    combatId
) {

    if (
        !confirm(
            "Delete this encounter?"
        )
    ) {
        return;
    }


    await del(
        "combats",
        combatId
    );


    render();

}


/* =========================================================
   MAPS
   ========================================================= */

async function renderMaps() {

    const page =
        document.getElementById(
            "page"
        );


    const maps =
        await getMyRecords(
            "maps"
        );


    page.innerHTML = `

        <div class="toolbar">

            <div>

                <h1 class="page-title">
                    Maps
                </h1>

                <p class="page-subtitle">
                    World and battle maps.
                </p>

            </div>


            <button
                class="primary-button"
                onclick="showMapForm()">

                + Add Map

            </button>

        </div>


        ${
            maps.length
                ? maps
                    .map(
                        map =>
                            `
                            <div class="card">

                                <div class="card-header">

                                    <div>

                                        <h2>
                                            ${esc(map.name)}
                                        </h2>

                                        <p>
                                            ${esc(
                                                map.description ||
                                                ""
                                            )}
                                        </p>

                                    </div>


                                    <div>

                                        <button
                                            class="small-button"
                                            onclick="
                                                showMapForm(
                                                    '${map.id}'
                                                )
                                            ">

                                            Edit

                                        </button>


                                        <button
                                            class="small-button"
                                            onclick="
                                                deleteMap(
                                                    '${map.id}'
                                                )
                                            ">

                                            Delete

                                        </button>

                                    </div>

                                </div>


                                ${
                                    map.image
                                        ? `
                                            <img
                                                class="map-image"
                                                src="${esc(
                                                    map.image
                                                )}">
                                        `
                                        : ""
                                }

                            </div>
                            `
                    )
                    .join("")
                : `
                    <div class="empty-state">

                        <strong>
                            No Maps
                        </strong>

                        Add a map to your campaign.

                    </div>
                `
        }

    `;

}


async function showMapForm(
    mapId=null
) {

    const map =
        mapId
            ? await one(
                "maps",
                mapId
            )
            : null;


    openModal(

        map
            ? "Edit Map"
            : "Add Map",

        `

        <form
            onsubmit="
                saveMap(
                    event,
                    '${mapId || ""}'
                )
            ">

            <div class="form-grid">

                <div class="form-field full">

                    <label>
                        Map Name
                    </label>

                    <input
                        id="mapName"
                        required
                        value="${esc(
                            map?.name ||
                            ""
                        )}">

                </div>


                <div class="form-field full">

                    <label>
                        Image URL
                    </label>

                    <input
                        id="mapImage"
                        required
                        value="${esc(
                            map?.image ||
                            ""
                        )}">

                </div>


                <div class="form-field full">

                    <label>
                        Description
                    </label>

                    <textarea
                        id="mapDescription">${esc(
                            map?.description ||
                            ""
                        )}</textarea>

                </div>

            </div>


            ${modalFormButtons()}

        </form>

        `
    );

}


async function saveMap(
    event,
    mapId
) {

    event.preventDefault();


    const existing =
        mapId
            ? await one(
                "maps",
                mapId
            )
            : null;


    const map = {

        id:
            mapId ||
            makeId("map"),

        ownerId:
            currentUserId,

        campaignId:
            currentCampaignId,

        name:
            document.getElementById(
                "mapName"
            ).value.trim(),

        image:
            document.getElementById(
                "mapImage"
            ).value.trim(),

        description:
            document.getElementById(
                "mapDescription"
            ).value.trim(),

        createdAt:
            existing?.createdAt ||
            new Date().toISOString(),

        updatedAt:
            new Date().toISOString()

    };


    await put(
        "maps",
        map
    );


    closeModal();

    showToast(
        "Map saved."
    );


    render();

}


async function deleteMap(id) {

    if (
        !confirm(
            "Delete this map?"
        )
    ) {
        return;
    }


    await del(
        "maps",
        id
    );


    render();

}


/* =========================================================
   SESSIONS
   ========================================================= */

async function renderSessions() {

    const page =
        document.getElementById(
            "page"
        );


    const sessions =
        await getMyRecords(
            "sessions"
        );


    page.innerHTML = `

        <div class="toolbar">

            <div>

                <h1 class="page-title">
                    Sessions
                </h1>

                <p class="page-subtitle">
                    Your campaign history.
                </p>

            </div>


            <button
                class="primary-button"
                onclick="showSessionForm()">

                + Add Session

            </button>

        </div>


        ${
            sessions.length
                ? sessions
                    .map(
                        session =>
                            `
                            <div class="card">

                                <div class="card-header">

                                    <div>

                                        <h2>
                                            Session
                                            ${esc(
                                                session.number ||
                                                ""
                                            )}
                                        </h2>

                                        <small>
                                            ${esc(
                                                session.date ||
                                                ""
                                            )}
                                        </small>

                                    </div>


                                    <div>

                                        <button
                                            class="small-button"
                                            onclick="
                                                showSessionForm(
                                                    '${session.id}'
                                                )
                                            ">

                                            Edit

                                        </button>


                                        <button
                                            class="small-button"
                                            onclick="
                                                deleteSession(
                                                    '${session.id}'
                                                )
                                            ">

                                            Delete

                                        </button>

                                    </div>

                                </div>


                                <p>
                                    ${esc(
                                        session.summary ||
                                        ""
                                    )}
                                </p>


                                ${
                                    session.events
                                        ? `
                                            <h3>
                                                Events
                                            </h3>

                                            <p>
                                                ${esc(
                                                    session.events
                                                )}
                                            </p>
                                        `
                                        : ""
                                }


                                ${
                                    session.unresolved
                                        ? `
                                            <h3>
                                                Unresolved
                                            </h3>

                                            <p>
                                                ${esc(
                                                    session.unresolved
                                                )}
                                            </p>
                                        `
                                        : ""
                                }

                            </div>
                            `
                    )
                    .join("")
                : `
                    <div class="empty-state">

                        <strong>
                            No Sessions
                        </strong>

                        Add your first session log.

                    </div>
                `
        }

    `;

}


async function showSessionForm(
    sessionId=null
) {

    const session =
        sessionId
            ? await one(
                "sessions",
                sessionId
            )
            : null;


    openModal(

        session
            ? "Edit Session"
            : "Add Session",

        `

        <form
            onsubmit="
                saveSession(
                    event,
                    '${sessionId || ""}'
                )
            ">

            <div class="form-grid">

                <div class="form-field">

                    <label>
                        Session Number
                    </label>

                    <input
                        id="sessionNumber"
                        type="number"
                        value="${esc(
                            session?.number ||
                            ""
                        )}">

                </div>


                <div class="form-field">

                    <label>
                        Date
                    </label>

                    <input
                        id="sessionDate"
                        type="date"
                        value="${esc(
                            session?.date ||
                            ""
                        )}">

                </div>


                <div class="form-field full">

                    <label>
                        Summary
                    </label>

                    <textarea
                        id="sessionSummary">${esc(
                            session?.summary ||
                            ""
                        )}</textarea>

                </div>


                <div class="form-field full">

                    <label>
                        Events
                    </label>

                    <textarea
                        id="sessionEvents">${esc(
                            session?.events ||
                            ""
                        )}</textarea>

                </div>


                <div class="form-field full">

                    <label>
                        Unresolved Issues
                    </label>

                    <textarea
                        id="sessionUnresolved">${esc(
                            session?.unresolved ||
                            ""
                        )}</textarea>

                </div>

            </div>


            ${modalFormButtons()}

        </form>

        `
    );

}


async function saveSession(
    event,
    sessionId
) {

    event.preventDefault();


    const existing =
        sessionId
            ? await one(
                "sessions",
                sessionId
            )
            : null;


    const session = {

        id:
            sessionId ||
            makeId("session"),

        ownerId:
            currentUserId,

        campaignId:
            currentCampaignId,

        number:
            document.getElementById(
                "sessionNumber"
            ).value,

        date:
            document.getElementById(
                "sessionDate"
            ).value,

        summary:
            document.getElementById(
                "sessionSummary"
            ).value.trim(),

        events:
            document.getElementById(
                "sessionEvents"
            ).value.trim(),

        unresolved:
            document.getElementById(
                "sessionUnresolved"
            ).value.trim(),

        createdAt:
            existing?.createdAt ||
            new Date().toISOString(),

        updatedAt:
            new Date().toISOString()

    };


    await put(
        "sessions",
        session
    );


    closeModal();

    showToast(
        "Session saved."
    );


    render();

}


async function deleteSession(id) {

    if (
        !confirm(
            "Delete this session?"
        )
    ) {
        return;
    }


    await del(
        "sessions",
        id
    );


    render();

}


/* =========================================================
   DICE
   ========================================================= */

function renderDice() {

    document.getElementById(
        "page"
    ).innerHTML = `

        <h1 class="page-title">
            Dice Roller
        </h1>

        <p class="page-subtitle">
            Roll dice for your game.
        </p>


        <div class="card">

            <div class="form-grid">

                <div class="form-field">

                    <label>
                        Number of Dice
                    </label>

                    <input
                        id="diceCount"
                        type="number"
                        min="1"
                        max="100"
                        value="1">

                </div>


                <div class="form-field">

                    <label>
                        Die
                    </label>

                    <select id="diceSides">

                        <option value="4">
                            d4
                        </option>

                        <option value="6" selected>
                            d6
                        </option>

                        <option value="8">
                            d8
                        </option>

                        <option value="10">
                            d10
                        </option>

                        <option value="12">
                            d12
                        </option>

                        <option value="20">
                            d20
                        </option>

                        <option value="100">
                            d100
                        </option>

                    </select>

                </div>


                <div class="form-field">

                    <label>
                        Modifier
                    </label>

                    <input
                        id="diceModifier"
                        type="number"
                        value="0">

                </div>

            </div>


            <div class="form-actions">

                <button
                    class="primary-button"
                    onclick="rollDice()">

                    🎲 Roll

                </button>

            </div>

        </div>


        <div
            id="diceResult"
            class="dice-result">

            Ready

        </div>

    `;

}


function rollDice() {

    const count =
        Math.max(
            1,
            Math.min(
                100,
                Number(
                    document.getElementById(
                        "diceCount"
                    ).value
                ) || 1
            )
        );


    const sides =
        Number(
            document.getElementById(
                "diceSides"
            ).value
        );


    const modifier =
        Number(
            document.getElementById(
                "diceModifier"
            ).value
        ) || 0;


    const rolls = [];


    for (
        let i=0;
        i<count;
        i++
    ) {

        rolls.push(
            Math.floor(
                Math.random() *
                sides
            ) + 1
        );

    }


    const total =
        rolls.reduce(
            (sum,value) =>
                sum + value,
            0
        ) +
        modifier;


    document.getElementById(
        "diceResult"
    ).innerHTML = `

        ${total}

        <div style="
            font-size:15px;
            margin-top:10px;
            color:var(--muted);
        ">

            Rolls:
            ${rolls.join(", ")}

            ${
                modifier
                    ? `
                        <br>
                        Modifier:
                        ${
                            modifier > 0
                                ? "+"
                                : ""
                        }${modifier}
                    `
                    : ""
            }

        </div>

    `;

}


/* =========================================================
   GENERATORS
   ========================================================= */

function renderGenerators() {

    document.getElementById(
        "page"
    ).innerHTML = `

        <h1 class="page-title">
            Generators
        </h1>

        <p class="page-subtitle">
            Generate names and campaign ideas.
        </p>


        <div class="card">

            <h2>
                Name Generator
            </h2>


            <div class="form-grid">

                <div class="form-field">

                    <label>
                        Theme
                    </label>

                    <input
                        id="nameTheme"
                        value="fantasy">

                </div>


                <div class="form-field">

                    <label>
                        Number of Names
                    </label>

                    <input
                        id="nameCount"
                        type="number"
                        min="1"
                        max="20"
                        value="5">

                </div>

            </div>


            <div class="form-actions">

                <button
                    class="primary-button"
                    onclick="generateNames()">

                    Generate Names

                </button>

            </div>


            <div
                id="nameOutput"
                class="generator-output">

                Your names will appear here.

            </div>

        </div>


        <div class="card">

            <h2>
                Town Generator
            </h2>


            <div class="form-grid">

                <div class="form-field">

                    <label>
                        Theme
                    </label>

                    <input
                        id="townTheme"
                        value="fantasy">

                </div>


                <div class="form-field">

                    <label>
                        Size
                    </label>

                    <select id="townSize">

                        <option>
                            Village
                        </option>

                        <option selected>
                            Town
                        </option>

                        <option>
                            City
                        </option>

                    </select>

                </div>

            </div>


            <div class="form-actions">

                <button
                    class="primary-button"
                    onclick="generateTown()">

                    Generate Town

                </button>

            </div>


            <div
                id="townOutput"
                class="generator-output">

                Your town will appear here.

            </div>

        </div>

    `;

}


function generateNames() {

    const theme =
        document.getElementById(
            "nameTheme"
        ).value.trim().toLowerCase();


    const count =
        Math.max(
            1,
            Math.min(
                20,
                Number(
                    document.getElementById(
                        "nameCount"
                    ).value
                ) || 5
            )
        );


    const pools = {

        fantasy: [
            "Ael",
            "Thar",
            "Mor",
            "Eld",
            "Val",
            "Kael",
            "Ryn",
            "Syl",
            "Vor",
            "Dra"
        ],

        nordic: [
            "Bjorn",
            "Eir",
            "Hal",
            "Rag",
            "Sven",
            "Tor",
            "Ulfr",
            "Yr"
        ],

        desert: [
            "Zar",
            "Rash",
            "Sam",
            "Nad",
            "Qad",
            "Az",
            "Mal",
            "Jah"
        ]

    };


    const endings = [
        "en",
        "ar",
        "is",
        "or",
        "an",
        "iel",
        "a",
        "os",
        "in",
        "eth"
    ];


    const pool =
        pools[theme] ||
        pools.fantasy;


    const names = [];


    for (
        let i=0;
        i<count;
        i++
    ) {

        names.push(

            pool[
                Math.floor(
                    Math.random() *
                    pool.length
                )
            ] +

            endings[
                Math.floor(
                    Math.random() *
                    endings.length
                )
            ]

        );

    }


    document.getElementById(
        "nameOutput"
    ).innerHTML =
        names
            .map(
                name =>
                    `<div>✦ ${esc(name)}</div>`
            )
            .join("");

}


function generateTown() {

    const theme =
        document.getElementById(
            "townTheme"
        ).value.trim();


    const size =
        document.getElementById(
            "townSize"
        ).value;


    const starts = [
        "Stone",
        "Raven",
        "Oak",
        "Silver",
        "Dragon",
        "Black",
        "High",
        "Green",
        "Moon",
        "Iron"
    ];


    const endings = [
        "ford",
        "haven",
        "watch",
        "fall",
        "hold",
        "mere",
        "wick",
        "reach",
        "stead",
        "rest"
    ];


    const name =
        starts[
            Math.floor(
                Math.random() *
                starts.length
            )
        ] +
        endings[
            Math.floor(
                Math.random() *
                endings.length
            )
        ];


    const industries = [
        "farming",
        "mining",
        "fishing",
        "trade",
        "logging",
        "crafting"
    ];


    const problems = [
        "A nearby ruin has recently been disturbed.",
        "Merchants have started disappearing.",
        "A local faction is gaining influence.",
        "Strange lights have appeared outside town.",
        "A valuable shipment has gone missing.",
        "Something has been frightening travelers."
    ];


    const industry =
        industries[
            Math.floor(
                Math.random() *
                industries.length
            )
        ];


    const problem =
        problems[
            Math.floor(
                Math.random() *
                problems.length
            )
        ];


    document.getElementById(
        "townOutput"
    ).innerHTML = `

        <h3>
            ${esc(name)}
        </h3>

        <p>
            <strong>
                Theme:
            </strong>
            ${esc(theme)}
        </p>

        <p>
            <strong>
                Size:
            </strong>
            ${esc(size)}
        </p>

        <p>
            <strong>
                Industry:
            </strong>
            ${esc(industry)}
        </p>

        <p>
            <strong>
                Adventure Hook:
            </strong>
            ${esc(problem)}
        </p>

    `;

}


/* =========================================================
   SETTINGS
   ========================================================= */

async function renderSettings() {

    const page =
        document.getElementById(
            "page"
        );


    const account =
        await one(
            "accounts",
            currentUserId
        );


    const campaigns =
        await getMyCampaigns();


    page.innerHTML = `

        <h1 class="page-title">
            Settings
        </h1>


        <div class="card">

            <h2>
                Account
            </h2>

            <p>
                Logged in as:
                <strong>
                    ${esc(
                        account?.username ||
                        ""
                    )}
                </strong>
            </p>


            <button
                class="danger-button"
                onclick="logout()">

                Log Out

            </button>

        </div>


        <div class="card">

            <h2>
                Campaigns
            </h2>


            ${
                campaigns.length
                    ? campaigns
                        .map(
                            c =>
                                `
                                <div class="toolbar">

                                    <strong>
                                        ${esc(c.name)}
                                    </strong>

                                    <div>

                                        <button
                                            class="small-button"
                                            onclick="
                                                showCampaignForm(
                                                    '${c.id}'
                                                )
                                            ">

                                            Edit

                                        </button>


                                        <button
                                            class="small-button"
                                            onclick="
                                                deleteCampaign(
                                                    '${c.id}'
                                                )
                                            ">

                                            Delete

                                        </button>

                                    </div>

                                </div>
                                `
                        )
                        .join("")
                    : `
                        <p>
                            No campaigns.
                        </p>
                    `
            }

        </div>


        <div class="card">

            <h2>
                Local Data
            </h2>

            <p>
                Campaign data is stored locally in this
                browser. Logging out does not delete it.
            </p>

            <button
                class="primary-button"
                onclick="exportAccountData()">

                Export Account Backup

            </button>

        </div>


        <div class="card">

            <h2>
                Data Folder
            </h2>

            <p>
                You can choose a folder on your computer
                where DM Toolkit can save a JSON backup.
            </p>

            <button
                class="secondary-button"
                onclick="chooseDataFolder()">

                Choose Data Folder

            </button>

            <span
                id="folderStatus"
                style="
                    margin-left:10px;
                    color:var(--muted);
                ">

                No folder linked.

            </span>

        </div>

    `;


    updateFolderStatus();

}


async function deleteCampaign(
    campaignId
) {

    if (
        !confirm(
            "Delete this campaign?"
        )
    ) {
        return;
    }


    const stores = [
        "entries",
        "characters",
        "combats",
        "maps",
        "sessions"
    ];


    for (
        const storeName of stores
    ) {

        const records =
            await all(
                storeName
            );


        for (
            const record of records
        ) {

            if (
                record.campaignId ===
                campaignId
            ) {

                await del(
                    storeName,
                    record.id
                );

            }

        }

    }


    await del(
        "campaigns",
        campaignId
    );


    if (
        currentCampaignId ===
        campaignId
    ) {

        currentCampaignId =
            null;

    }


    showToast(
        "Campaign deleted."
    );


    render();

}


/* =========================================================
   EXPORT
   ========================================================= */

async function collectAccountData() {

    const campaigns =
        await getMyCampaigns();


    const campaignIds =
        new Set(
            campaigns.map(
                c => c.id
            )
        );


    const result = {

        version: 3,

        exportedAt:
            new Date().toISOString(),

        account:
            await one(
                "accounts",
                currentUserId
            ),

        campaigns,

        entries: [],
        characters: [],
        combats: [],
        maps: [],
        sessions: []

    };


    for (
        const storeName of [
            "entries",
            "characters",
            "combats",
            "maps",
            "sessions"
        ]
    ) {

        const records =
            await all(
                storeName
            );


        result[storeName] =
            records.filter(
                record =>
                    record.ownerId ===
                    currentUserId &&
                    campaignIds.has(
                        record.campaignId
                    )
            );

    }


    /*
       Do not export the password.
    */

    if (result.account) {

        delete result.account.password;

    }


    return result;

}


async function exportAccountData() {

    const data =
        await collectAccountData();


    downloadJSON(
        data,
        "dm-toolkit-account-backup.json"
    );


    showToast(
        "Account backup exported."
    );

}


async function exportCampaign() {

    if (!currentCampaignId) {

        showToast(
            "Open a campaign first."
        );

        return;

    }


    const data =
        await collectAccountData();


    data.campaigns =
        data.campaigns.filter(
            c =>
                c.id ===
                currentCampaignId
        );


    const campaignIds =
        new Set([
            currentCampaignId
        ]);


    for (
        const storeName of [
            "entries",
            "characters",
            "combats",
            "maps",
            "sessions"
        ]
    ) {

        data[storeName] =
            data[storeName].filter(
                record =>
                    campaignIds.has(
                        record.campaignId
                    )
            );

    }


    downloadJSON(
        data,
        "dm-toolkit-campaign.json"
    );


    showToast(
        "Campaign exported."
    );

}


function downloadJSON(
    data,
    filename
) {

    const blob =
        new Blob(
            [
                JSON.stringify(
                    data,
                    null,
                    2
                )
            ],
            {
                type:
                    "application/json"
            }
        );


    const url =
        URL.createObjectURL(
            blob
        );


    const link =
        document.createElement(
            "a"
        );


    link.href =
        url;

    link.download =
        filename;


    link.click();


    URL.revokeObjectURL(
        url
    );

}


/* =========================================================
   IMPORT
   ========================================================= */

async function importCampaign(
    input
) {

    const file =
        input.files?.[0];


    if (!file) {
        return;
    }


    try {

        const text =
            await file.text();


        const data =
            JSON.parse(text);


        if (
            !data.campaigns ||
            !Array.isArray(
                data.campaigns
            )
        ) {

            throw new Error(
                "Invalid campaign backup."
            );

        }


        const campaignMap =
            new Map();


        for (
            const oldCampaign
            of data.campaigns
        ) {

            const newCampaign = {

                ...oldCampaign,

                id:
                    makeId("campaign"),

                ownerId:
                    currentUserId

            };


            campaignMap.set(
                oldCampaign.id,
                newCampaign.id
            );


            await put(
                "campaigns",
                newCampaign
            );


            currentCampaignId =
                newCampaign.id;

        }


        for (
            const storeName
            of [
                "entries",
                "characters",
                "combats",
                "maps",
                "sessions"
            ]
        ) {

            const records =
                Array.isArray(
                    data[storeName]
                )
                    ? data[storeName]
                    : [];


            for (
                const oldRecord
                of records
            ) {

                const newRecord = {

                    ...oldRecord,

                    id:
                        makeId(
                            storeName
                        ),

                    ownerId:
                        currentUserId,

                    campaignId:
                        campaignMap.get(
                            oldRecord.campaignId
                        ) ||
                        currentCampaignId

                };


                await put(
                    storeName,
                    newRecord
                );

            }

        }


        await updateCampaignTitle();


        showToast(
            "Import complete."
        );


        render();


    } catch(error) {

        console.error(error);


        showToast(
            "Could not import that file."
        );

    }


    input.value = "";

}


/* =========================================================
   OPTIONAL PHYSICAL DATA FOLDER
   ========================================================= */

async function chooseDataFolder() {

    /*
       Chrome's File System Access API allows the user
       to explicitly give this application access to
       a folder.

       The browser does NOT allow us to silently choose
       the folder containing index.html.
    */

    if (
        !window.showDirectoryPicker
    ) {

        showToast(
            "This browser does not support linked data folders."
        );

        return;

    }


    try {

        const handle =
            await window.showDirectoryPicker();


        const permission =
            await handle.requestPermission({
                mode: "readwrite"
            });


        if (
            permission !==
            "granted"
        ) {

            showToast(
                "Folder permission was not granted."
            );

            return;

        }


        /*
           Store the directory handle locally.
        */

        await put(
            "settings",
            {
                id:
                    "dataFolder",
                handle
            }
        );


        await writeDataFolderBackup(
            handle
        );


        updateFolderStatus();


        showToast(
            "Data folder linked."
        );


    } catch(error) {

        console.log(
            "Folder selection cancelled."
        );

    }

}


async function writeDataFolderBackup(
    handle
) {

    if (!handle) {
        return;
    }


    try {

        const data =
            await collectAccountData();


        const fileHandle =
            await handle.getFileHandle(
                "dm-toolkit-data.json",
                {
                    create: true
                }
            );


        const writable =
            await fileHandle.createWritable();


        await writable.write(
            JSON.stringify(
                data,
                null,
                2
            )
        );


        await writable.close();


    } catch(error) {

        console.error(
            "Could not write folder backup:",
            error
        );

    }

}


async function getDataFolderHandle() {

    try {

        const setting =
            await one(
                "settings",
                "dataFolder"
            );


        return setting?.handle ||
            null;

    } catch {

        return null;

    }

}


async function updateFolderStatus() {

    const status =
        document.getElementById(
            "folderStatus"
        );


    if (!status) {
        return;
    }


    const handle =
        await getDataFolderHandle();


    status.textContent =
        handle
            ? "Linked: " + handle.name
            : "No folder linked.";

}


/* =========================================================
   STARTUP
   ========================================================= */

async function init() {

    try {

        /*
           IndexedDB version 2 creates the new
           accounts store while keeping the old
           campaign data.
        */

        await openDB();


        /*
           The settings store was not part of the
           original database.

           It cannot be created without another
           database version upgrade, so the physical
           folder feature will gracefully fall back
           if that store is unavailable.

           The core account/campaign system does not
           depend on it.
        */

        await restoreLogin();


    } catch(error) {

        console.error(
            error
        );


        document.getElementById(
            "authScreen"
        ).innerHTML = `

            <div class="auth-card">

                <div class="auth-dragon">
                    ⚠️
                </div>

                <h1>
                    Database Error
                </h1>

                <p>
                    DM Toolkit could not open its
                    local database.
                </p>

                <p>
                    ${esc(error.message)}
                </p>

            </div>

        `;

    }

}


init();